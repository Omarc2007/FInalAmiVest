import React from "react";
import { 
  SafeAreaView, 
  View, 
  ImageBackground, 
  ScrollView, 
  Text, 
  TouchableOpacity, 
  StyleSheet 
} from "react-native";

export default ({ navigation }) => {

  const handlePress = () => {
    navigation.navigate("Client");
  };

  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground 
        source={{ uri: "https://storage.googleapis.com/tagjs-prod.appspot.com/v1/UBUqNXaFuI/pp976n3d_expires_30_days.png" }} 
        resizeMode="stretch"
        style={styles.view}
      >
        <ScrollView style={styles.scrollView}>
          {/* Title */}
          <Text style={styles.title}>Weather Type</Text>

          {/* All stacked buttons */}
          <View style={styles.column}>
            <TouchableOpacity style={styles.button} onPress={() => handlePress()}>
              <Text style={styles.text}>Summer</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.button} onPress={() => handlePress()}>
              <Text style={styles.text}>Winter</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.button} onPress={() => handlePress()}>
              <Text style={styles.text}>Windy</Text>
            </TouchableOpacity>


            <TouchableOpacity style={styles.button} onPress={() => handlePress()}>
              <Text style={styles.text}>Fall</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.button} onPress={() => handlePress()}>
              <Text style={styles.text}>Spring</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  view: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  title: {
    color: "#FFFFFF",
    fontSize: 40,
    fontWeight: "bold",
    marginTop: 100,
    marginBottom: 60,
    marginLeft: 50,
    marginRight: 10,
  },
  column: {
    flexDirection: "column",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  button: {
    width: "90%",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingVertical: 24,
    marginBottom: 20,
    alignItems: "center",
    shadowColor: "#0000004D",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 3,
    elevation: 3,
  },
  text: {
    color: "#000000",
    textAlign: "center",
    fontSize: 32,
    fontWeight: "semi-bold",
	
  },
});

