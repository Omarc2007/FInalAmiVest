import React from "react";
import {
  SafeAreaView,
  View,
  ImageBackground,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

export default function Help({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={{
          uri: "https://storage.googleapis.com/tagjs-prod.appspot.com/v1/UBUqNXaFuI/qn4015ac_expires_30_days.png",
        }}
        resizeMode="stretch"
        style={styles.view}
      >
        <ScrollView style={styles.scrollView}>
          {/* Title */}
          <Text style={styles.title}>I would like to</Text>

          {/* Call Option */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("CallCategorization")}
            accessible={true}
            accessibilityLabel="Calling Preference"
            accessibilityHint="Double tap to choose calling-only assignments"
          >
            <Text style={styles.cardText}>Call</Text>
          </TouchableOpacity>

          {/* Text Option */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("TextCategorization")}
            accessible={true}
            accessibilityLabel="Texting Preference"
            accessibilityHint="Double tap to choose texting-only assignments"
          >
            <Text style={styles.cardText}>Text</Text>
          </TouchableOpacity>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  view: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    shadowColor: "#00000040",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 4,
    elevation: 4,
  },
 title: {
    color: "#FFFFFF",
    fontSize: 40,
    fontWeight: "bold",
    marginTop: 100,
    marginBottom: 60,
    marginLeft: 50,
    marginRight: 10,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingVertical: 72,
    marginBottom: 44,
    marginHorizontal: 49,
    shadowColor: "#0000004D",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 3,
    elevation: 3,
    alignItems: "center",
  },
  cardText: {
    color: "#000000",
    fontSize: 50,
    textAlign: "center",
    marginHorizontal: 37,
    fontWeight: "semi-bold",
  },
});