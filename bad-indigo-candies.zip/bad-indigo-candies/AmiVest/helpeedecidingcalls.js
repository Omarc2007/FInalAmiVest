import React, { useRef, useEffect } from "react";
import { 
  SafeAreaView, 
  ScrollView, 
  Text, 
  ImageBackground, 
  Image, 
  Animated, 
  Easing, 
  TouchableOpacity, 
  View,
  Dimensions
} from "react-native";

export default function FindingSomeone({ navigation }) {
  const spinValue = useRef(new Animated.Value(0)).current;

  // Spin animation
  useEffect(() => {
    Animated.loop(
      Animated.timing(spinValue, {
        toValue: 1,
        duration: 3000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
  }, [spinValue]);

  const spin = spinValue.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  const screenWidth = Dimensions.get("window").width;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FFFFFF" }}>
      <ImageBackground
        source={{ uri: "https://storage.googleapis.com/tagjs-prod.appspot.com/v1/UBUqNXaFuI/0rix7saa_expires_30_days.png" }}
        resizeMode="stretch"
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 28,
            paddingVertical: 40,
          }}
        >
          {/* Title */}
          <Text style={{ color: "#FFFFFF", fontSize: 28, fontWeight: "bold", marginBottom: 44, alignSelf: "flex-start" }}>
            Finding Someone For You!
          </Text>

          {/* Spinning Hanger */}
          <View style={{ alignItems: "center", marginBottom: 92, width: screenWidth }}>
            <Animated.Image
              source={{ uri: "https://cdn-icons-png.flaticon.com/128/18/18409.png" }}
              style={{
                width: 122,
                height: 101,
                transform: [{ rotate: spin }],
                backgroundColor: "transparent",
              }}
              resizeMode="contain"
            />
          </View>

          {/* Leave Queue Button */}
          <TouchableOpacity
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 16,
              paddingVertical: 20,
              paddingHorizontal: 26,
              shadowColor: "#0000004D",
              shadowOpacity: 0.3,
              shadowOffset: { width: 0, height: 1 },
              shadowRadius: 3,
              elevation: 3,
              width: "100%",
              alignItems: "center",
            }}
            onPress={() => alert("Leave Queue pressed!")}
          >
            <Text style={{ fontSize: 24, color: "#000000", fontWeight: "bold" }}>
              Leave Queue
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
}