import React from "react";
import { 
  SafeAreaView, 
  View, 
  ImageBackground, 
  ScrollView, 
  Text, 
  TouchableOpacity, 
  StyleSheet 
} from "react-native";

export default ({ navigation }) => {

  const handlePress = () => {
    navigation.navigate("TagsPicks"); 
  };

  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground 
        source={{ uri: "https://storage.googleapis.com/tagjs-prod.appspot.com/v1/UBUqNXaFuI/nihlxhri_expires_30_days.png" }} 
        resizeMode="stretch"
        style={styles.view}
      >
        <ScrollView style={styles.scrollView}>
          <Text style={styles.title}>
            What type of fashion style are you looking for?
          </Text>

          {/* Chic + Vintage */}
          <View style={styles.rowWrap}>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Chic</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Vintage</Text>
            </TouchableOpacity>
          </View>

          {/* Athletic + Streetwear */}
          <View style={styles.rowWrap}>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Athletic</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Streetwear</Text>
            </TouchableOpacity>
          </View>

          {/* Formal + Beach */}
          <View style={styles.rowWrap}>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Formal</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Beach</Text>
            </TouchableOpacity>
          </View>

          {/* Casual + Preppy */}
          <View style={styles.rowWrap}>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Casual</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={handlePress}>
              <Text style={styles.text}>Preppy</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  view: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  title: {
    color: "#FFFFFF",
    fontSize: 40,
    fontWeight: "bold",
    marginTop: 107,
    marginBottom: 60,
    marginLeft: 50,
    marginRight: 10,
  },
  rowWrap: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 20,
    marginBottom: 25,
  },
  button: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    paddingVertical: 24,
    marginHorizontal: 5,
    alignItems: "center",
    shadowColor: "#0000004D",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 3,
    elevation: 3,
  },
  text: {
    color: "#000000",
    fontSize: 22,
    textAlign: "center",
  },
});

